# 4.0.0 (2015-11-02)

 * update handlebars to v4
 * fix caching of non default filename layouts

# 3.1.1 (2015-09-11)

 * fix localsAsTemplateData when cache is enabled

# 3.1.0 (2015-06-10)

 * make @data available to layouts

# 3.0.1 (2015-03-12)

 * honor custom extension when using view engine layouts

# 3.0.0 (2015-03-09)

 * update handlebars to 3.x

# 2.8.0 (2014-12-26)

 * update to handlebars 2.x

# 2.7.0 (2014-06-02)

 * fix registering directories of partials on windows
 * add api to expose locals as template data

# 2.5.0 / 2014-02-19

 * updated handlebars to 1.3.0

# 2.4.0 / 2013-09-13
